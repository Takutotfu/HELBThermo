package com.example.helbthermo;

// Design Pattern Observer
public interface Observer {
    void update(Object o);
}
