mvn clean 
mvn test
